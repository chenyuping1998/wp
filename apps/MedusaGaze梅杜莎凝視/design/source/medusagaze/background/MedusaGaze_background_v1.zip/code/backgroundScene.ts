import { Container, Graphics, Mesh, MeshGeometry, Sprite, type Texture } from 'pixi.js';
import { FRACTURE_PIECES } from './symbolMotion';
import { BACKGROUND_SIZE, CLOUDS, BRAZIERS, STATUES, STATUE_SECONDS, cloudPosition, cloudVisibility, statueEnvelope, statuePiecePose, flamePoint, mixTint, clamp } from './backgroundMotion';

type Textures = Record<string, Texture>;
/** The exact same Pixi renderer is used in the game and the offline review. */
export function createBackgroundScene(textures: Textures) {
	const root = new Container(); root.label = 'Medusa plaza / fixed architecture'; root.eventMode = 'none';
	const day = new Sprite(textures.mgBgBase), night = new Sprite(textures.mgBgFree);
	for (const sprite of [day, night]) { sprite.width = BACKGROUND_SIZE.width; sprite.height = BACKGROUND_SIZE.height; root.addChild(sprite); }
	night.alpha = 0;
	const cloudLayer = new Container(), skyMask = new Graphics().rect(155, 0, 1615, 145).fill(0xffffff);
	root.addChild(cloudLayer, skyMask); cloudLayer.mask = skyMask;
	const clouds = CLOUDS.map(data => { const sprite = new Sprite(textures.mgBgCloud); sprite.anchor.set(0.5); sprite.position.set(data.x, data.y); sprite.width = data.width; sprite.height = data.height; cloudLayer.addChild(sprite); return sprite; });
	const ownedGeometry: MeshGeometry[] = [];
	const flames = BRAZIERS.map((bowl, index) => {
		const group = new Container(); group.position.set(bowl.x, bowl.y); root.addChild(group);
		const glow = new Sprite(textures.fxGlow); glow.anchor.set(0.5); glow.y = -20; glow.width = 145; glow.height = 100; glow.tint = 0xffa747; glow.alpha = 0.19; glow.blendMode = 'add'; group.addChild(glow);
		const side = 10, rows = 14, positions = new Float32Array((side + 1) * (rows + 1) * 2), uvs = new Float32Array(positions.length), indices: number[] = [];
		for (let y = 0; y <= rows; y++) for (let x = 0; x <= side; x++) {
			const i = (y * (side + 1) + x) * 2; uvs[i] = x / side; uvs[i + 1] = y / rows;
			positions[i] = (x / side - 0.5) * 76; positions[i + 1] = (y / rows - 1) * 112;
			if (x < side && y < rows) { const a = y * (side + 1) + x; indices.push(a, a + 1, a + side + 1, a + 1, a + side + 2, a + side + 1); }
		}
		const geometry = new MeshGeometry({ positions, uvs, indices: new Uint32Array(indices) }); ownedGeometry.push(geometry);
		const mesh = new Mesh({ geometry, texture: textures.mgBgFlame }); group.addChild(mesh);
		return { group, geometry, positions, uvs, index };
	});
	const statues = STATUES.map(data => {
		const shadow = new Sprite(textures.fxGlow); shadow.anchor.set(0.5); shadow.position.set(data.x, data.y - 8); shadow.width = data.width * 1.04; shadow.height = 38; shadow.tint = 0x473c34; shadow.alpha = 0.20; root.addChild(shadow);
		const group = new Container(); group.position.set(data.x, data.y); root.addChild(group);
		const texture = textures[data.key], intact = new Sprite(texture); intact.anchor.set(0.5, 1); intact.width = data.width; intact.height = data.height; group.addChild(intact);
		const pieces = new Container(); group.addChild(pieces);
		const meshes = FRACTURE_PIECES.map(points => {
			const uv = points.map(([x, y]) => [x + 0.5, (y + 0.5) * data.plinth]);
			const cx = uv.reduce((sum, p) => sum + p[0] - 0.5, 0) / uv.length * data.width;
			const cy = uv.reduce((sum, p) => sum + p[1] - 1, 0) / uv.length * data.height;
			const positions = new Float32Array(uv.flatMap(([u, v]) => [(u - 0.5) * data.width - cx, (v - 1) * data.height - cy]));
			const indices: number[] = []; for (let i = 1; i < uv.length - 1; i++) indices.push(0, i, i + 1);
			const geometry = new MeshGeometry({ positions, uvs: new Float32Array(uv.flat()), indices: new Uint32Array(indices) }); ownedGeometry.push(geometry);
			const mesh = new Mesh({ geometry, texture }); mesh.position.set(cx, cy); pieces.addChild(mesh); return { mesh, cx, cy };
		});
		const baseGeometry = new MeshGeometry({ positions: new Float32Array([-data.width/2,(data.plinth-1)*data.height,data.width/2,(data.plinth-1)*data.height,-data.width/2,0,data.width/2,0]), uvs: new Float32Array([0,data.plinth,1,data.plinth,0,1,1,1]), indices: new Uint32Array([0,1,2,1,3,2]) }); ownedGeometry.push(baseGeometry);
		const base = new Mesh({ geometry: baseGeometry, texture }); pieces.addChild(base);
		const cracks = new Sprite(textures.fxCrack3); cracks.anchor.set(0.5, 1); cracks.width = data.width; cracks.height = data.height; cracks.tint = 0x49433e;
		const mask = new Sprite(texture); mask.anchor.set(0.5, 1); mask.width = data.width; mask.height = data.height; group.addChild(cracks, mask); cracks.mask = mask;
		return { data, group, intact, pieces, meshes, base, cracks };
	});
	let elapsed = 0, nightness = 0, target = 0, burstAge = STATUE_SECONDS, reduced = false, disposed = false;
	function update(seconds: number) {
		if (disposed) return;
		const dt = Math.max(0, seconds);
		if (!reduced) { elapsed += dt; burstAge = Math.min(STATUE_SECONDS, burstAge + dt); }
		nightness += Math.sign(target - nightness) * Math.min(Math.abs(target - nightness), dt / (reduced ? 0.25 : 1));
		night.alpha = nightness;
		clouds.forEach((cloud, index) => { cloud.x = cloudPosition(elapsed, CLOUDS[index].x, CLOUDS[index].width); cloud.tint = mixTint(0xffffff, 0x8997c2, nightness); cloud.alpha = (0.8 - nightness * 0.28) * cloudVisibility(cloud.x, CLOUDS[index].width); });
		for (const flame of flames) {
			flame.group.alpha = nightness; flame.group.visible = nightness > 0.001;
			if (!flame.group.visible) continue;
			for (let i = 0; i < flame.positions.length; i += 2) { const p = flamePoint(flame.uvs[i], flame.uvs[i + 1], reduced ? 0 : elapsed, flame.index * 2.43); flame.positions[i] = p.x * 76; flame.positions[i + 1] = p.y * 112; }
			flame.geometry.getBuffer('aPosition').update();
		}
		const state = statueEnvelope(burstAge), tint = mixTint(0xffffff, 0x9cafd1, nightness);
		for (const statue of statues) {
			statue.intact.tint = tint; statue.base.tint = tint;
			statue.intact.visible = state.split < 0.00001; statue.pieces.visible = !statue.intact.visible;
			statue.cracks.alpha = statue.intact.visible ? state.crack * 0.6 : 0;
			statue.meshes.forEach(({ mesh, cx, cy }, index) => { const p = statuePiecePose(index, burstAge, statue.data.width, statue.data.height); mesh.position.set(cx + p.x, cy + p.y); mesh.rotation = p.rotation; mesh.tint = tint; });
		}
	}
	function setBounds(width: number, height: number) { const scale = Math.max(width / BACKGROUND_SIZE.width, height / BACKGROUND_SIZE.height); root.scale.set(scale); root.position.set((width - BACKGROUND_SIZE.width * scale) / 2, (height - BACKGROUND_SIZE.height * scale) / 2); }
	update(0);
	return { root, update, setBounds,
		setNight(value: boolean) { target = value ? 1 : 0; },
		setReducedMotion(value: boolean) { reduced = value; if (value) burstAge = STATUE_SECONDS; update(0); },
		burstStatues() { if (disposed || reduced || burstAge < STATUE_SECONDS) return false; burstAge = 0; update(0); return true; },
		snapshot() { return { elapsed, nightness: clamp(nightness), burstAge, reduced, cloudX: clouds.map(c => c.x), architecture: { x: day.x, y: day.y, rotation: day.rotation } }; },
		destroy() { if (disposed) return; disposed = true; root.destroy({ children: true }); ownedGeometry.forEach(geometry => geometry.destroy()); },
	};
}
