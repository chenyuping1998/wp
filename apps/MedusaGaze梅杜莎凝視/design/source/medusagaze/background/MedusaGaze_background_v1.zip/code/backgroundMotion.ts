/** Scene coordinates stay fixed. Only clouds, night fire and statue pieces move. */
export const BACKGROUND_SIZE = { width: 1920, height: 1080 } as const;
export const CLOUD_PIXELS_PER_SECOND = BACKGROUND_SIZE.width / 5 / 60;
export const STATUE_SECONDS = 1.2;
export const FLAME_ANCHOR_V = 1434 / 1536;
export const BACKGROUND_KEYS = ['mgBgBase', 'mgBgFree', 'mgBgCloud', 'mgBgTourist', 'mgBgIcecream', 'mgBgFlame', 'fxCrack3', 'fxGlow'] as const;
export const CLOUDS = [
	{ x: 580, y: 64, width: 600, height: 200 },
	{ x: 1360, y: 84, width: 400, height: 134 },
	{ x: -980, y: 75, width: 480, height: 160 },
	{ x: -200, y: 80, width: 450, height: 150 },
] as const;
export const BRAZIERS = [{ x: 188, y: 712 }, { x: 1735, y: 712 }] as const;
export const STATUES = [
	{ key: 'mgBgTourist', x: 370, y: 1002, width: 400, height: 800, plinth: 0.895 },
	{ key: 'mgBgIcecream', x: 1743, y: 995, width: 300, height: 600, plinth: 0.89 },
] as const;
export const clamp = (t: number) => Math.max(0, Math.min(1, t));
export const ease = (t: number) => { const p = clamp(t); return p * p * (3 - 2 * p); };
export const cloudPosition = (time: number, start: number, _width: number) => {
	const margin = 600, span = BACKGROUND_SIZE.width + margin * 2;
	return ((start + time * CLOUD_PIXELS_PER_SECOND + margin) % span + span) % span - margin;
};
/** Fade in open sky before reaching the opaque foreground column masks. */
export const cloudVisibility = (x: number, width: number) => ease((x - 155 - width / 2) / 120) * ease((1770 - width / 2 - x) / 120);
export const statueEnvelope = (age: number) => {
	const split = age < 0.16 ? 0 : age < 0.42 ? ease((age - 0.16) / 0.26) : age < 0.58 ? 1 : (1 - clamp((age - 0.58) / 0.54)) ** 3;
	return { split: age < 0 || age >= STATUE_SECONDS ? 0 : split,
		crack: age >= 0 && age < 0.23 ? ease((age - 0.03) / 0.10) : 0 };
};
export const statuePiecePose = (index: number, age: number, width: number, height: number) => {
	const { split } = statueEnvelope(age);
	return { x: [-0.13, 0.12, 0.16, -0.08, -0.16][index] * width * split,
		y: ([-0.025, -0.02, 0.035, 0.065, 0.025][index] * split + 0.045 * split * split) * height,
		rotation: (index % 2 ? 1 : -1) * (0.15 + index * 0.035) * split };
};
export const flamePoint = (u: number, v: number, time: number, seed: number) => {
	// Bottom rows remain fixed on the bowl. Independent tip timing avoids a loop
	// of the entire flame scaling up and down like a breathing halo.
	const weight = Math.max(0, (FLAME_ANCHOR_V - v) / FLAME_ANCHOR_V) ** 2;
	const sway = Math.sin(time * 5.7 + seed + v * 4.8) * 0.028 + Math.sin(time * 9.3 + seed * 1.8 - v * 3) * 0.012;
	return { x: u - 0.5 + sway * weight, y: v - FLAME_ANCHOR_V - Math.sin(time * 7.1 + seed + u * 3.8) * 0.018 * weight };
};
export const mixTint = (a: number, b: number, t: number) => {
	let result = 0;
	for (const shift of [16, 8, 0]) result |= Math.round(((a >> shift) & 255) * (1 - t) + ((b >> shift) & 255) * t) << shift;
	return result;
};
