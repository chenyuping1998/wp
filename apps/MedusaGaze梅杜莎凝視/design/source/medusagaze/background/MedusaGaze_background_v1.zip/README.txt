Medusa Gaze 背景動態 v1 / 2026-10-24

六張正式素材以內建 image_gen 依使用者核准的 style_ref.png 製作。完整提詞見 BACKGROUND_PROMPTS.md；生成母圖 *_original.png 保存在專案同資料夾。

已接入本 app：
- 白天 bg_base.jpg / 黃昏 bg_free.jpg，固定構圖，約1秒交叉淡入淡出。
- cloud.png：4個雲群錯開進出，每分鐘384場景像素，即1920寬場景的1/5；前景柱邊緣前淡出，不切斷雲形。
- statue_tourist.png / statue_icecream.png：大獎開始時一起裂開、分成5塊、約1.2秒內回復；底座固定，不做待機搖晃。每次大獎只觸發一次。
- flame.png：只在免費遊戲點亮。以實際火根位置(原稿1434/1536)固定在火盆口，火尖局部變形；兩處不同步。
- 碎裂事件接入既有 sfx_statues_crack，音量0.6，不循環。

動畫程式：src/game/backgroundMotion.ts、backgroundScene.ts；接線：src/components/Background.svelte。
所有修改限本 app，未更改 wp/packages。
頁面隱藏時暫停；尊重 prefers-reduced-motion。相同Pixi場景程式供遊戲與 preview/index.html 使用。
進場時在素材到齊後直接掛入現有Pixi父容器，卸載時移除ticker並釋放場景與geometry；不在effect內延後註冊onMount。

預演：MedusaGaze_background_v1.webm，約12秒，靜音。這是共用遊戲背景程式的瀏覽器畫布錄影，並非Stake Engine實機錄影。
check_background.mjs 驗證雲速、遮罩邊緣、石像原位還原、火根固定與網格不翻面。建置、型別與本機瀏覽器結果見 delivery-status.json。

本包的透明圖為真正RGBA；背景為1920x1080 JPG。其餘角色、UI及盤框仍依各自階段製作。最終Stake Engine上機驗收由使用者上傳後確認。
